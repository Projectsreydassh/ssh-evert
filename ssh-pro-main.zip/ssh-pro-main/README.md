# REIDASSH ⚡

# @REIDASSH

*SSH-PRO🍷🗿
```
apt install wget -y; bash <(wget -qO- raw.githubusercontent.com/Projectsreydassh/ssh-evert/main/ssh-plus)

```
